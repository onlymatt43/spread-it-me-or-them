# SPREAD IT Landing Page

A simple landing page for the upcoming SPREAD IT app.

## 🚀 Deploy on Vercel

1. Create a GitHub repository and upload these files.
2. Go to [https://vercel.com/new](https://vercel.com/new) and import your repo.
3. Vercel will automatically detect and deploy it as a static site.

---
© 2025 SPREAD IT
